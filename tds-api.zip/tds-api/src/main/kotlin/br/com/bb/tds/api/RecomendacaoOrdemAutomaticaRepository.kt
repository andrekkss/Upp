package br.com.bb.tds.api

import org.springframework.data.jpa.repository.JpaRepository
import org.springframework.stereotype.Repository

@Repository
interface RecomendacaoOrdemAutomaticaRepository: JpaRepository<RecomendacaoOrdemAutomatica, RecomendacaoOrdemAutomaticaIdentity>