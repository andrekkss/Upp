package br.com.bb.tds.api

import java.sql.Timestamp
import java.time.LocalDate
import java.time.LocalDateTime
import javax.persistence.*

@Entity
@Table(name = "RCM_ORD_AUTC")
@IdClass(RecomendacaoOrdemAutomaticaIdentity::class)
data class RecomendacaoOrdemAutomatica(
        @Id
        @Column(name = "DT_RCM_ORD_AUTC")
        val data: LocalDate = LocalDate.now(),

        @Id
        @Column(name = "NR_SEQL_RCM_ORD_AUTC")
        val sequencial: Int = 0,

        @Column(name = "CD_TIP_PRC")
        val tipoProcessamento: Char = 'O',

        @Column(name = "CD_TIT", columnDefinition = "CHAR(9)")
        val titulo: String = "",

        @Column(name = "CD_PSCT_RCM", columnDefinition = "CHAR(1)")
        val codigoProcessamento: String = "",

        @Column(name = "CD_TIP_NEGO", columnDefinition = "CHAR(1)")
        val tipoNegociacao: String = "",

        @Column(name = "TS_INC_RCM")
        val timestamp: LocalDateTime = LocalDateTime.now(),

        @Column(name = "CD_ROBO_RCM")
        val codigoRobo: Int = 0,

        @Column(name = "VL_ATI_MMT_RCM", columnDefinition = "decimal", precision = 11, scale = 2)
        val valorAtivo: Double = 0.0,

        @Column(name = "VL_LOT_MIN")
        val valorLoteMinimo: Int = 0,

        @Column(name = "TS_ECR_RCM")
        val timestampEncerramento: LocalDateTime?,

        @Column(name = "CD_AGRM_NEGO")
        val codigoAlgoritmo: Short?,

        @Column(name = "DT_RCM_OGNL")
        val dataRecomendacaoOriginal: LocalDate?,

        @Column(name = "NR_SEQL_RCM_OGNL")
        val sequencialRecomendacaoOriginal: Int?,

        @Column(name = "DT_ORD_OGNL")
        val dataOrdemOriginal: LocalDate?,

        @Column(name = "NR_ORD_OGNL")
        val numeroOrdemOriginal: Int?,

        @Column(name = "CD_MTV_SAID", columnDefinition = "decimal", precision = 4, scale = 0)
        val motivoSaida: Double?,

        @Column(name = "PC_RSTD_MMT_SAID", columnDefinition = "decimal", precision = 11, scale = 6)
        val percentualSaida: Double?
)

