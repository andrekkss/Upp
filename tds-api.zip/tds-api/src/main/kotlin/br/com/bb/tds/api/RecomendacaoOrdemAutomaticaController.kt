package br.com.bb.tds.api

import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.web.bind.annotation.*
import javax.validation.Valid


// https://www.baeldung.com/spring-data-jpa-query-by-date
@RestController
@RequestMapping("/api")
class RecomendacaoOrdemAutomaticaController(private val invrAtiRoboRepository: RecomendacaoOrdemAutomaticaRepository) {


    @GetMapping("/investidores")
    fun getAllRecomendacoes(): List<RecomendacaoOrdemAutomatica> =
            invrAtiRoboRepository.findAll()

    @GetMapping("/chaves")
    fun getChaves(): List<String> = listOf("Seu madruga", "chaves", "chiquinha")
/*

    @PostMapping("/investidores")
    fun createNewArticle(@Valid @RequestBody investidor: RecomendacaoOrdemAutomatica): RecomendacaoOrdemAutomatica =
            invrAtiRoboRepository.save(investidor)


   @GetMapping("/investidores/{id}")
    fun getInvestidorById(@PathVariable(value = "id") articleId: Short): ResponseEntity<RecomendacaoOrdemAutomatica> {
        return invrAtiRoboRepository.findById(articleId).map { article ->
            ResponseEntity.ok(article)
        }.orElse(ResponseEntity.notFound().build())
    }

    @PutMapping("/investidores/{id}")
    fun updateInvestidorById(@PathVariable(value = "id") investidorId: Short,
                             @Valid @RequestBody newArticle: RecomendacaoOrdemAutomatica): ResponseEntity<RecomendacaoOrdemAutomatica> {

        return invrAtiRoboRepository.findById(investidorId).map { investidorExistente ->
            val updatedInvestidor: RecomendacaoOrdemAutomatica = investidorExistente
                    .copy(invrAtiRobo = newArticle.invrAtiRobo, cdInvt = newArticle.cdInvt)
            ResponseEntity.ok().body(invrAtiRoboRepository.save(updatedInvestidor))
        }.orElse(ResponseEntity.notFound().build())

    }

    @DeleteMapping("/investidores/{id}")
    fun deleteInvestidorById(@PathVariable(value = "id") investidorId: Short): ResponseEntity<Void> {

        return invrAtiRoboRepository.findById(investidorId).map { investidor  ->
            invrAtiRoboRepository.delete(investidor)
            ResponseEntity<Void>(HttpStatus.OK)
        }.orElse(ResponseEntity.notFound().build())

    }*/
}

//insert into RCM_ORD_AUTC (DT_RCM_ORD_AUTC, NR_SEQL_RCM_ORD_AUTC, CD_TIP_PRC, CD_TIT, CD_PSCT_RCM, CD_TIP_NEGO, CD_ROBO_RCM, VL_ATI_MMT_RCM, VL_LOT_MIN) values ('2019-02-01', 1, 2,'tosco', '1', '1', 1, 30.2, 20.3);