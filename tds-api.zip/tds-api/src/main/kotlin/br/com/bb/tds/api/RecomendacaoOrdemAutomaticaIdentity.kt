package br.com.bb.tds.api

import java.io.Serializable
import java.sql.Timestamp
import java.time.LocalDate
import javax.persistence.*

//@Embeddable
data class RecomendacaoOrdemAutomaticaIdentity(
    val data: LocalDate = LocalDate.now(),
    val sequencial: Int = 0
) : Serializable

